alert("Nu körs kod utanför en funktion. Detta körs alltid när sidan laddas");

function ViewAlert( )
{
    var text = "Hej nu körs JS kod som anropas via en funktion";
    alert(text);
}