class Fest
{
    constructor(namn, plats, starttid)
    {
        this.namn = namn;
        this.plats = plats;
        this.starttid = starttid;
    }
}

class Person
{
    constructor()
    {
        this.namn;
        this.email;
    }

    AntalDeltagare()
    {
        return 
    }
}

var fest = new Fest("halloweenfest", "Karlavägen 29A", "19.00");
var p1 = new Person();
var p2 = new Person();