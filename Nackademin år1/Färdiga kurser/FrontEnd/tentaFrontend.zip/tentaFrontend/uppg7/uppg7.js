var div = document.getElementById("div1");
div.addEventListener("click", function(){
    div.className = "divClass";
})
 

