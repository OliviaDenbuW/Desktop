var div = document.getElementById("myDiv");
div.addEventListener("click", function(){
    div.className = "changeBackgroundColor";
});