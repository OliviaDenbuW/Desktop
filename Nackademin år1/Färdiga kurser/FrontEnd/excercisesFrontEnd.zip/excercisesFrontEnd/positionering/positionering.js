/* var myDiv = document.getElementById("div2");
myDiv.addEventListener("mouseenter", function(){

    var thisDiv = event.target;

    thisDiv.className = "changeBackgroundColor";

    
}) */