var minText = document.getElementById("text1");
minText.innerHTML = "Ny text via js-kod";