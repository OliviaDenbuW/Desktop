function resize(elem, percent)
{
    elem.style.fontSize = percent;
}