document.body.addEventListener("click", function() {
  
    document.body.className = "changeBackgroundColor";
})

